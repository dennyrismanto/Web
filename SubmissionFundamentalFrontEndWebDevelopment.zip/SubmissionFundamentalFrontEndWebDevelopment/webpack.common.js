const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");

module.exports = {
    entry: "./src/index.js",
    output: {
        path: path.resolve(__dirname, "dist"),
        filename: "bundle.js"
    },
    module: {
        rules: [
            /* style and css loader */
            {
                test: /\.css$/,
                use: [
                    {
                        loader: "style-loader"
                    },
                    {
                        loader: "css-loader"
                    }
                ]   
            },
            {
                test: /\.(png|svg|jpg|gif)$/,
                use: [
                  'file-loader',
                ],
            },
        ]
    },
    /* plugin */
    plugins: [
        /* HTML Webpack Plugin Index*/
        new HtmlWebpackPlugin({
            template: "./src/index.html",
            filename: "index.html"
        }),
        /* HTML Webpack Plugin Panduan*/
        new HtmlWebpackPlugin({
            template: "./src/panduan.html",
            filename: "panduan.html"
        }),
        /* HTML Webpack Plugin Pengumuman*/
        new HtmlWebpackPlugin({
            template: "./src/pengumuman.html",
            filename: "pengumuman.html"
        }),
        /* HTML Webpack Plugin */
        new HtmlWebpackPlugin({
            template: "./src/kontak.html",
            filename: "kontak.html"
        }),
        /* HTML Webpack Plugin Main*/
        new HtmlWebpackPlugin({
            template: "./src/main.html",
            filename: "main.html"
        }),
    ]
}