import movies from './movies.js';

class DataSource {
    static searchmovie(keyword) { 
        return fetch(`https://api.themoviedb.org/3/search/movie?api_key=3518e25bfb42356cb488bed8defab956&language=en-US&query=${keyword}&include_adult=true`)
            .then(response => {
                return response.json()
            })
            .then(responseJson => {
                if(responseJson.results) {
                    return Promise.resolve(responseJson.results);
                } else {
                    return Promise.reject(`${keyword} is not found`)
                }
            })
    }
}

export default DataSource;