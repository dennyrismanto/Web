class movieItem extends HTMLElement {
    set movie(movie) {
        this._movie = movie;
        this.render();
    }
    render() {
        this.innerHTML = `
        <img class="fan-art-movie" src="https://image.tmdb.org/t/p/w500${this._movie.poster_path}" alt="Fan Art">
        <div class="movie-info">
            <h2>${this._movie.original_title}</h2>
            <p>${this._movie.overview}</p>
        </div>`;
    }
}

customElements.define("movie-item", movieItem);