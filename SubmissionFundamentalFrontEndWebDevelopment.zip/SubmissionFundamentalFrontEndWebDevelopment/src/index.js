import "./style/style.css";
import main from "./script/view/finder.js";
document.addEventListener("DOMContentLoaded", main);

import "regenerator-runtime";
import "./script/component/app-bar.js";


import pic1 from './images/1.jpg';
import pic2 from './images/2.jpg';
import pic3 from './images/3.jpg';
import pic4 from './images/4.jpg';
document.querySelector('#imageFigure1').src = pic1;
document.querySelector('#imageFigure2').src = pic2;
document.querySelector('#imageFigure3').src = pic3;
document.querySelector('#imageFigure4').src = pic4;



