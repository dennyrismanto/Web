class ImageFigure extends HTMLElement {

    connectedCallback() {
      this.src = this.getAttribute("src") || null;
      this.render();
    }
  
    render(){
      this.innerHTML = `
        <style>
        figure {
          width: 200px;
          margin: center;
        }
        </style>

        <figure>
          <img src="${this.src}">
        </figure>
      `;
    }
    
  }

customElements.define("image-figure", ImageFigure);