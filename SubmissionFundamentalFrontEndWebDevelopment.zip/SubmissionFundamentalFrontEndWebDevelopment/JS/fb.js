// Your web app's Firebase configuration
var firebaseConfig = {
  apiKey: "AIzaSyBT3rMibUyKMBmeMfUs5Bb9hCw5xGGfvMk",
  authDomain: "websiteprogrammerpinggiran.firebaseapp.com",
  databaseURL: "https://websiteprogrammerpinggiran.firebaseio.com",
  projectId: "websiteprogrammerpinggiran",
  storageBucket: "websiteprogrammerpinggiran.appspot.com",
  messagingSenderId: "685028864234",
  appId: "1:685028864234:web:5925297d4fc09c81bf6793"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
	
	
	function signUp(){
		
		var email = document.getElementById("email");
		var password = document.getElementById("password");
		
		const promise = auth.createUserWithEmailAndPassword(email.value, password.value);
		promise.catch(e => alert(e.message));
		
		alert("Signed Up");
	}
	
	
	
	function signIn(){
		
		var email = document.getElementById("email");
		var password = document.getElementById("password");
		
		const promise = auth.signInWithEmailAndPassword(email.value, password.value);
		promise.catch(e => alert(e.message));
		alert("Sign In " + email.value)

		firebase.auth().onAuthStateChanged(function(user) {
			if (user == email.value, password.value) {
				window.location = "./main.html"
			  // User is signed in.
			} else {
				alert("Selamat datang di LMS Programmer Pinggiran")
			  // No user is signed in.
			}
		});
		
	}
	
	
	function signOut(){
		
		auth.signOut();
		window.location = "./index.html"
		alert("Signed Out");
	}


	